package com.ktds.blog.service;

import com.ktds.blog.dto.BoardDTO;
import com.ktds.blog.dto.DetailDTO;
import com.ktds.blog.dto.PageDTO;
import com.ktds.blog.dto.RankingDTO;
import com.ktds.blog.repository.BoardRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class BoardService {
    private final BoardRepository boardRepository;
    private final int BOARDS_PER_PAGE = 5;
    private final int PAGES_PER_SCREEN = 10;
    public int save(BoardDTO boardDTO) {
        return boardRepository.save(boardDTO);
    }

    public List<BoardDTO> findAll() {
        return boardRepository.findAll();
    }

    public void updateHit(Long id) {
        boardRepository.updateHit(id);
    }

    public BoardDTO findById(Long id) {
        return boardRepository.findById(id);
    }

    public void remove(Long id) {
        boardRepository.remove(id);
    }

    public void update(BoardDTO boardDTO) {
        boardRepository.update(boardDTO);
    }

    public List<BoardDTO> pagingList(int page) {
        int pagingStart = (page - 1) * BOARDS_PER_PAGE;
        Map<String, Integer> pagingParams = new HashMap<>();
        pagingParams.put("start", pagingStart);
        pagingParams.put("limit", BOARDS_PER_PAGE);
        return boardRepository.pagingList(pagingParams);
    }

    public PageDTO pagingParam(int page) {
        // 전체 글 갯수 조회
        int boardCount = boardRepository.boardCount();
        // 전체 페이지 갯수 계산(10/3=3.33333 => 4)
        int maxPage = (int) (Math.ceil((double) boardCount / BOARDS_PER_PAGE));
        // 시작 페이지 값 계산(1, 4, 7, 10, ~~~~)
        int startPage = (((int)(Math.ceil((double) page / PAGES_PER_SCREEN))) - 1) * PAGES_PER_SCREEN + 1;
        // 끝 페이지 값 계산(3, 6, 9, 12, ~~~~)
        int endPage = startPage + PAGES_PER_SCREEN - 1;
        if (endPage > maxPage) {
            endPage = maxPage;
        }
        PageDTO pageDTO = new PageDTO();
        pageDTO.setPage(page);
        pageDTO.setMaxPage(maxPage);
        pageDTO.setStartPage(startPage);
        pageDTO.setEndPage(endPage);
        return pageDTO;
    }

    public List<RankingDTO> find() {
        return boardRepository.find();
    }

    public RankingDTO findOne(Long escapeId) {
        return boardRepository.findOne(escapeId);
    }

    public List<BoardDTO> detailPagingList(int page,Long escapeId) {
        int pagingStart = (page - 1) * BOARDS_PER_PAGE;
        DetailDTO detailDTO= new DetailDTO();
        detailDTO.setPagingStart(pagingStart);
        detailDTO.setBOARDS_PER_PAGE(BOARDS_PER_PAGE);
        detailDTO.setEscape_id(escapeId);
        return boardRepository.detailPagingList(detailDTO);
    }

    public PageDTO detailPagingParam(int page,Long escapeId) {
        int boardCount = boardRepository.detailBoardCount(escapeId);
        // 전체 페이지 갯수 계산(10/3=3.33333 => 4)
        int maxPage = (int) (Math.ceil((double) boardCount / BOARDS_PER_PAGE));
        // 시작 페이지 값 계산(1, 4, 7, 10, ~~~~)
        int startPage = (((int)(Math.ceil((double) page / PAGES_PER_SCREEN))) - 1) * PAGES_PER_SCREEN + 1;
        // 끝 페이지 값 계산(3, 6, 9, 12, ~~~~)
        int endPage = startPage + PAGES_PER_SCREEN - 1;
        if (endPage > maxPage) {
            endPage = maxPage;
        }
        PageDTO pageDTO = new PageDTO();
        pageDTO.setPage(page);
        pageDTO.setMaxPage(maxPage);
        pageDTO.setStartPage(startPage);
        pageDTO.setEndPage(endPage);
        return pageDTO;
    }
}
