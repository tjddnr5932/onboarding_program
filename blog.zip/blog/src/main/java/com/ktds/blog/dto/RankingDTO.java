package com.ktds.blog.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RankingDTO {
    private Long escape_id;
    private String escape_name;
    private String escape_address;
    private Long escape_ranking;
    private Long escape_point;
}
