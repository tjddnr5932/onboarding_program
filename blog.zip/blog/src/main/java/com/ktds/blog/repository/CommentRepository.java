package com.ktds.blog.repository;

import com.ktds.blog.dto.CommentDTO;
import lombok.RequiredArgsConstructor;
import org.apache.ibatis.session.SqlSession;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@RequiredArgsConstructor
public class CommentRepository {
    private final SqlSessionTemplate sql;
    public void save(CommentDTO commentDTO) {
        sql.insert("Comment.save",commentDTO);
    }

    public List<CommentDTO> findById(Long id) {
        return sql.selectList("Comment.findById", id);
    }

    public void comment_delete(Long commentId) {
        sql.delete("Comment.comment_delete",commentId);
    }

    public void updateCount(Long escapeId) {
        sql.update("Comment.updateCount", escapeId);
    }

    public void updateCount_(Long escapeId) {
        sql.update("Comment.updateCount_", escapeId);
    }
}
