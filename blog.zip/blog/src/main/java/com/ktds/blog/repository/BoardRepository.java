package com.ktds.blog.repository;

import com.ktds.blog.dto.BoardDTO;
import com.ktds.blog.dto.DetailDTO;
import com.ktds.blog.dto.RankingDTO;
import lombok.RequiredArgsConstructor;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

import javax.swing.*;
import java.util.List;
import java.util.Map;

@Repository
@RequiredArgsConstructor
public class BoardRepository {
    private final SqlSessionTemplate sql;
    public int save(BoardDTO boardDTO) {
        return sql.insert("Board.save", boardDTO);
    }

    public List<BoardDTO> findAll() {
        return sql.selectList("Board.findAll");
    }

    public void updateHit(Long id) {
        sql.update("Board.updateHits",id);
    }

    public BoardDTO findById(Long id) {
        return sql.selectOne("Board.findById",id);
    }


    public void remove(Long id) {
        sql.delete("Board.delete",id);
    }

    public void update(BoardDTO boardDTO) {
        sql.update("Board.update",boardDTO);
    }

    public List<BoardDTO> pagingList(Map<String, Integer> pagingParams) {
        return sql.selectList("Board.pagingList", pagingParams);
    }

    public int boardCount() {
        return sql.selectOne("Board.boardCount");
    }

    public List<RankingDTO> find() {
        return sql.selectList("Board.find");
    }

    public RankingDTO findOne(Long escapeId) {
        return sql.selectOne("Board.findOne",escapeId);
    }

    public List<BoardDTO> detailPagingList(DetailDTO detailDTO) {
        return sql.selectList("Board.detailPagingList", detailDTO);
    }

    public int detailBoardCount(Long escapeId) {
        return sql.selectOne("Board.detailBoardCount",escapeId);
    }
}
