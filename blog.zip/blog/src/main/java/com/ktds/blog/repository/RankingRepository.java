package com.ktds.blog.repository;

import com.ktds.blog.dto.RankingDTO;
import lombok.RequiredArgsConstructor;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@RequiredArgsConstructor
public class RankingRepository {
    private final SqlSessionTemplate sql;
    public List<RankingDTO> findAll_ranking() {
        return sql.selectList("Ranking.findAll_ranking");
    }
    public List<RankingDTO> rankingList(Map<String, Integer> rankingParams) {
        return sql.selectList("Ranking.rankingList", rankingParams);
    }
    public int rankingCount() {
        return sql.selectOne("Ranking.rankingCount");
    }


}
