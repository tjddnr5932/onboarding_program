package com.ktds.blog.service;

import com.ktds.blog.dto.CommentDTO;
import com.ktds.blog.repository.CommentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CommentService {
    private final CommentRepository commentRepository;
    public void save(Long boardId, CommentDTO commentDTO) {
        commentDTO.setBoardId(boardId);
        commentRepository.save(commentDTO);
    }

    public List<CommentDTO> findById(Long id) {
        return commentRepository.findById(id);
    }

    public void comment_delete(Long commentId) {
        commentRepository.comment_delete(commentId);
    }

    public void updateCount(Long escapeId) {
        commentRepository.updateCount(escapeId);
    }

    public void updatecount_(Long escapeId) {
        commentRepository.updateCount_(escapeId);
    }
}
