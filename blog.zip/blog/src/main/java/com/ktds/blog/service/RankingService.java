package com.ktds.blog.service;

import com.ktds.blog.dto.PageDTO;
import com.ktds.blog.dto.RankingDTO;
import com.ktds.blog.repository.RankingRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class RankingService {
    private final RankingRepository rankingRepository;
    private final int BOARDS_PER_PAGE = 9;
    private final int PAGES_PER_SCREEN = 10;
    public List<RankingDTO> findAll_ranking() {
        return rankingRepository.findAll_ranking();
    }

    public List<RankingDTO> rankingList(int page) {
        int rankingStart = (page - 1) * BOARDS_PER_PAGE;
        Map<String, Integer> rankingParams = new HashMap<>();
        rankingParams.put("start", rankingStart);
        rankingParams.put("limit", BOARDS_PER_PAGE);
        return rankingRepository.rankingList(rankingParams);

    }

    public PageDTO rankingParam(int page) {
        int rankingCount = rankingRepository.rankingCount();
        // 전체 페이지 갯수 계산(10/3=3.33333 => 4)
        int maxPage = (int) (Math.ceil((double) rankingCount / BOARDS_PER_PAGE));
        // 시작 페이지 값 계산(1, 4, 7, 10, ~~~~)
        int startPage = (((int)(Math.ceil((double) page / PAGES_PER_SCREEN))) - 1) * PAGES_PER_SCREEN + 1;
        // 끝 페이지 값 계산(3, 6, 9, 12, ~~~~)
        int endPage = startPage + PAGES_PER_SCREEN - 1;
        if (endPage > maxPage) {
            endPage = maxPage;
        }
        PageDTO pageDTO = new PageDTO();
        pageDTO.setPage(page);
        pageDTO.setMaxPage(maxPage);
        pageDTO.setStartPage(startPage);
        pageDTO.setEndPage(endPage);
        return pageDTO;
    }
}
