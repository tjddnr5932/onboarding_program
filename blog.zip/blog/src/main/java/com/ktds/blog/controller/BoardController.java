package com.ktds.blog.controller;

import com.ktds.blog.dto.BoardDTO;
import com.ktds.blog.dto.CommentDTO;
import com.ktds.blog.dto.PageDTO;
import com.ktds.blog.dto.RankingDTO;
import com.ktds.blog.service.BoardService;
import com.ktds.blog.service.CommentService;
import com.ktds.blog.service.RankingService;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.Banner;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.xml.stream.events.Comment;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.fasterxml.jackson.databind.type.LogicalType.Map;


@Controller
@RequestMapping("/board")
@RequiredArgsConstructor
public class BoardController {
    private final BoardService boardService;
    private final RankingService rankingService;

    @GetMapping("/save") // HTTP GET 요청에 대한 처리를 위한 매핑
    public String saveForm(Model model) {
        List<RankingDTO> escape = boardService.find();
        model.addAttribute("escape",escape);
        return "save"; // "save" 뷰 이름을 반환하여 해당 JSP 파일을 표시
    }

    @PostMapping("/save")
    public String save(@ModelAttribute BoardDTO boardDTO){
        int result = boardService.save(boardDTO);
        if (result > 0){
            return "redirect:/board/";
        } else{
          return "save";
        }
    }
    @GetMapping("/")
    public String findAll(Model model){
        List<BoardDTO> all = boardService.findAll();
        model.addAttribute("boardList",all);
        return "list";
    }

    @GetMapping
    public String findById(@RequestParam("id") Long id,Model model){
        boardService.updateHit(id);
        BoardDTO boardDTO = boardService.findById(id);
        model.addAttribute("board",boardDTO);
        return "detail";
    }

    @GetMapping("/delete")
    public String remove(@RequestParam("id") Long id){
        boardService.remove(id);
        return "redirect:/board/";
    }

    @GetMapping("/update")
    public String update(@RequestParam("id") Long id,Model model){
        BoardDTO boardDTO = boardService.findById(id);
        Long escape_id = boardDTO.getEscape_id();
        RankingDTO rankingDTO = boardService.findOne(escape_id);
        model.addAttribute("ranking", rankingDTO);
        model.addAttribute("board", boardDTO);
        return "update";
    }

    @PostMapping("/update")
    public String update(BoardDTO boardDTO, Model model) {
        boardService.update(boardDTO);
        BoardDTO dto = boardService.findById(boardDTO.getId());
        model.addAttribute("board", dto);
        return "detail";
    }

    @GetMapping("/paging")
    public String paging(Model model, @RequestParam(value = "page", required = false, defaultValue = "1") int page) {
        List<BoardDTO> boardList = boardService.pagingList(page);
        PageDTO pageDTO = boardService.pagingParam(page);
        model.addAttribute("boardList", boardList);
        model.addAttribute("paging", pageDTO);
        return "paging";
    }

    @GetMapping("/ranking")
    public String ranking(Model model,@RequestParam(value = "pages", required = false, defaultValue = "1") int pages){
        List<RankingDTO> ranking = rankingService.rankingList(pages);
        PageDTO pageDTO = rankingService.rankingParam(pages);
        model.addAttribute("rankingList",ranking);
        model.addAttribute("ranking", pageDTO);
        return "ranking_detail";
    }

    @GetMapping("/escaping")
    @ResponseBody
    public RankingDTO escaping(@RequestParam("id") Long escapingId) {
        return boardService.findOne(escapingId);
    }

    @GetMapping("/detailpage/{escapeId}")
    public String detailpaging(Model model, @RequestParam(value = "page", required = false, defaultValue = "1") int page,@PathVariable("escapeId") Long escapeId) {
        List<BoardDTO> detailBoardList = boardService.detailPagingList(page,escapeId);
        PageDTO pageDTO = boardService.detailPagingParam(page, escapeId);
        RankingDTO rankingDTO = boardService.findOne(escapeId);
        model.addAttribute("boardList", detailBoardList);
        model.addAttribute("paging", pageDTO);
        model.addAttribute("escape",escapeId);
        model.addAttribute("ranking",rankingDTO);
        return "detailpage";
    }
}
