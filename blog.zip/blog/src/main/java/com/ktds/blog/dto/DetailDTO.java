package com.ktds.blog.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DetailDTO {
    private Long escape_id;
    private int pagingStart;
    private int BOARDS_PER_PAGE;
}
