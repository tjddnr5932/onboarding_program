package com.ktds.blog.controller;

import com.ktds.blog.dto.BoardDTO;
import com.ktds.blog.dto.CommentDTO;
import com.ktds.blog.dto.RankingDTO;
import com.ktds.blog.service.BoardService;
import com.ktds.blog.service.CommentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/board")
public class CommentController {
    private final CommentService commentService;
    private final BoardService boardService;

    @PostMapping("/{id}/comment")
    public String save(@PathVariable("id") Long id, @ModelAttribute CommentDTO commentDTO) {
        commentService.save(id, commentDTO);
        BoardDTO boardDTO = boardService.findById(id);
        Long escape_id = boardDTO.getEscape_id();
        commentService.updateCount(escape_id);
        return "redirect:/board/" + id + "/comment";
    }

    @GetMapping("/{id}/comment")
    public String findById(@PathVariable("id") Long id, Model model) {
        boardService.updateHit(id);
        List<CommentDTO> comments = commentService.findById(id);
        BoardDTO boardDTO = boardService.findById(id);
        Long escape_id = boardDTO.getEscape_id();
        RankingDTO rankingDTO = boardService.findOne(escape_id);
        model.addAttribute("ranking", rankingDTO);
        model.addAttribute("board",boardDTO);
        model.addAttribute("comments",comments);
        return "new_detail";
    }

    @GetMapping("/{boardId}/comment/{commentId}")
    public String comment_delete(@PathVariable("boardId") Long boardId,@PathVariable("commentId") Long commentId){
        commentService.comment_delete(commentId);
        BoardDTO boardDTO = boardService.findById(boardId);
        Long escape_id = boardDTO.getEscape_id();
        commentService.updatecount_(escape_id);
        return "redirect:/board/" + boardId + "/comment";
    }
}
